# test_catalog
App web2py per la gestione del Catalogo delle Prestazioni in Laboratorio
Database utilizzato mysql
Versione python 2.7.x
Bootstrap 3
JQuery
